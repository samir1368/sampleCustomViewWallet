package com.example.myapplication.interfaces;

public interface WalletClickListener {
     void walletItemClicked(int position) ;
}
